// CompileIntercept.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include "CompileIntercept.h"
//#include <shlwapi.h>
//#include "adoint.h"
//#include "minhook.h"
//#include "traps.hpp"
#include "MethodsWrapper.h"
#include "atlctl.h"
//#include "1cpptlb.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

//#import "msado15.dll" no_namespace rename("EOF", "EndOfFile")

//

//{ATL::CStringT<wchar_t,class StrTraitMFC_DLL<wchar_t,class ATL::ChTraitsCRT<wchar_t>>> };
	
//
//TODO: If this DLL is dynamically linked against the MFC DLLs,
//		any functions exported from this DLL which call into
//		MFC must have the AFX_MANAGE_STATE macro added at the
//		very beginning of the function.
//
//		For example:
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// normal function body here
//		}
//
//		It is very important that this macro appear in each
//		function, prior to any calls into MFC.  This means that
//		it must appear as the first statement within the 
//		function, even before any object variable declarations
//		as their constructors may generate calls into the MFC
//		DLL.
//
//		Please see MFC Technical Notes 33 and 58 for additional
//		details.
//

#pragma once

#ifndef HEADER1C_PATH
	#define HEADER1C_PATH "1cheaders"
#endif
//typedef PCHAR CString;

//typedef class ATL::CStringT< TCHAR, StrTraitMFC_DLL< TCHAR > > CString;
// CCompileInterceptApp
#define IMPORT_1C __declspec(dllimport)

#pragma comment (lib,HEADER1C_PATH "/libs/basic.lib")
#pragma comment (lib,HEADER1C_PATH "/libs/bkend.lib")
#pragma comment (lib,HEADER1C_PATH "/libs/blang.lib")
#pragma comment (lib,HEADER1C_PATH "/libs/br32.lib")
#pragma comment (lib,HEADER1C_PATH "/libs/dbeng32.lib")
#pragma comment (lib,HEADER1C_PATH "/libs/editr.lib")
#pragma comment (lib,HEADER1C_PATH "/libs/frame.lib")
#pragma comment (lib,HEADER1C_PATH "/libs/moxel.lib")
#pragma comment (lib,HEADER1C_PATH "/libs/rgproc.lib")
#pragma comment (lib,HEADER1C_PATH "/libs/seven.lib")
#pragma comment (lib,HEADER1C_PATH "/libs/txtedt.lib")
#pragma comment (lib,HEADER1C_PATH "/libs/type32.lib")
#pragma comment (lib,HEADER1C_PATH "/libs/userdef.lib")


class IMPORT_1C CProfile7
{
public:
	 CProfile7(char const *,struct CProfileEntry7 const *);	//26
	virtual  ~CProfile7(void);	//89
	int  AddEntry(struct CProfileEntry7 const *);	//137
	virtual void  Attach(class CProfile7 *);	//170
protected:
	void  ConstructProp(int);	//207
	void  DestructProp(int);	//313
public:
	virtual void  Detach(class CProfile7 *);	//315
	int  FindEntry(char const *)const;	//427
	int  FindEntry(struct CProfileEntry7 const *)const;	//428
	class CProfile7 *  FindProfile(char const *);	//432
	class CNumeric const &  GetCNumericProp(int)const;	//468
protected:
	class CItemList *  GetChildList(class CItemList *,char const *);	//473
public:
	unsigned long  GetColorProp(int)const;	//475
	class CDate   GetDateProp(int)const;	//489
	double  GetDoubleProp(int)const;	//501
	struct CProfileEntry7 const *  GetEntryAt(int)const;	//507
	int  GetEntryCount(void)const;	//508
	struct __POSITION *  GetFirstProfile(void);	//519
	class CFont *  GetFontProp(int)const;	//527
	struct HFONT__ *  GetHFONTProp(int)const;	//529
	int  GetIntProp(int)const;	//545
	char const *  GetKey(void)const;	//574
	int  GetLOGFONTProp(int,struct tagLOGFONTA &)const;	//575
	long  GetLongProp(int)const;	//587
	class CProfile7 *  GetNextProfile(struct __POSITION * &);	//638
	class CProfile7 *  GetParentProfile(void);	//662
	void *  GetPointerProp(int)const;	//665
	CString const &  GetStringProp(int)const;	//718
protected:
	class CItem *  GetValueItem(class CItemList *,struct CProfileEntry7 const *);	//746
	static CString   LOGFONTtoString(struct tagLOGFONTA const &);	//842
	void  Load(class CItemList *,char const *);	//846
public:
	int  Load(char const *,char const *);	//847
protected:
	static CString   ProfileGetString(char const *,char const *,char const *);	//1205
	static int  ProfileWriteString(char const *,char const *,char const *);	//1206
	void  PropFromString(int,char const *);	//1207
	void  PropToString(int,CString &);	//1208
public:
	void  RemoveEntry(int);	//1242
	void  RemoveEntry(struct CProfileEntry7 const *);	//1243
	void  Reset(void);	//1267
protected:
	void  Save(class CItemList *,char const *);	//1270
public:
	int  Save(char const *,char const *);	//1271
	void  Serialize(class CArchive &);	//1307
	void  SetCNumericProp(int,class CNumeric const &);	//1320
	void  SetColorProp(int,unsigned long);	//1326
	void  SetDateProp(int,class CDate);	//1334
	void  SetDoubleProp(int,double);	//1341
	void  SetFontProp(int,class CFont *);	//1350
	void  SetHFONTProp(int,struct HFONT__ *);	//1353
	void  SetIntProp(int,int);	//1360
	void  SetKey(char const *);	//1379
	void  SetLOGFONTProp(int,struct tagLOGFONTA const &);	//1380
	void  SetLongProp(int,long);	//1386
	void  SetPointerProp(int,void *);	//1408
	void  SetStringProp(int,char const *);	//1424
protected:
	static int  StringtoLOGFONT(char const *,struct tagLOGFONTA &);	//1466
};


class IMPORT_1C CAppFrame:public CWinApp
{
public:
	void  AddMenu(struct HMENU__ *,int);	//142
	void  AddOptionsPage(struct _GUID const &,struct IUnknown *);	//145
	virtual int  DoMessageBox(char const *,unsigned int,unsigned int);	//327
	long  DoOptionsDialog(void);	//328
	int  FindOptionsPage(struct _GUID const &);	//431
	class CTBManager *  GetToolBarManager(void);	//736
	void  InitMenus(unsigned int,unsigned int);	//769
	int  IsWaiting(void);	//828
	virtual int  OnIdle(long);	//1021
	void  RemoveOptionsPage(struct _GUID const &);	//1248
	void  RemoveOptionsPage(struct _GUID const &,struct IUnknown *);	//1249
	int  SetNoSounds(int)const;	//1395
	int  StartWait(void);	//1461
	int  StopWait(unsigned int);	//1462
	int  StopWait(char const *);	//1463
	void  UpdateMainFrmMenu(void);	//1491
	int  WaitProc(unsigned int);	//1493
	int  WaitProc(char const *);	//1494

	DECLARE_MESSAGE_MAP()
};


class IMPORT_1C CApp7:public CAppFrame //CWinApp
{
public:
	DWORD buf[0x300];
public:
	CApp7(void);	//7
	virtual  ~CApp7(void);	//122
	void  AdjustDirectories(void);	//367
	int  AttachAddInDLL(char const *);	//373
	void  BindAddInContext(char const *,class CAddInContext *);	//382
	int  CheckDirectories(void);	//406
	void  CloseDataBase(void);	//420
	void  DoPageSetupDialog(void);	//557
	int  FindSpecialFile(char const *,CString &,char const *)const;	//652
	class CUserCommandContaner *  GetCommandManager(void);	//684

	virtual char const *  GetDDFName(void);	//705
	virtual char const *  GetDDSQLFName(void);	//706
	virtual char const *  GetSQLAddrFName(void);	//1088
	virtual char const *  GetMDFName(void);	//779
	virtual char const *  GetConfigFName(void);	//686
	virtual char const *  GetLockFName(void);	//773
	virtual char const *  GetDefSpellingFName(void);	//716

	virtual void  ActivateMessageDevice(int,int);	//338
	virtual void  ClearMessageDevice(void);	//413

	int  GetExitCode(void)const;	//727
	class CAdminService *  GetLog(void);	//774
	class CRect GetMarginsRect(void);	//781
	class CMetaDataCont *  GetMetaData(void);	//829
	unsigned int  GetModeMask(void)const;	//857
	unsigned int  GetMouseScrollLines(int);	//861
	struct HFONT__ *  GetProfileFont(int);	//990
	void  GetProfileFont(int,struct tagLOGFONTA &)const;	//991
	class CProfile7 *  GetProps(void);	//1022
	CString   GetRegisteredUserCompany(void);	//1030
	CString   GetRegisteredUserName(void);	//1031
	class CRightsContainer *  GetRightsManager(void);	//1034
	unsigned int  GetToolBarPos(void)const;	//1122
	void  GetUserDefContainers(class CDocument * *,class CDocument * *);	//1132
	CString   GetUserSystemCaption(void);	//1133
	void  InitAddInService(void);	//1184
	int  InitDataBase(void);	//1186
	void  InitParamsPages(void);	//1189
	int  InitProps(void);	//1190
	int  IsExclusiveMode(void);	//1216
	int  IsGrantedToRecentList(void);	//1219
	int  IsModeEnabled(unsigned int)const;	//1223
	int  LoadAddInDLL(char const *);	//1293
	int  LoadMetaData(char const *);	//1298
	virtual void  LockMessageDevice(int);	//1305
	void  OnDBClosing(void);	//1388
	void  OnDBOpened(void);	//1389
	virtual int  OnIdle(long);	//1433
	int  OpenDataBase(int,int,int);	//1602
	void  ProcessAddinEvents(void);	//1626
protected:
	virtual long  ProcessWndProcException(class CException *,struct tagMSG const *);	//1632
public:
	CString ReadStatusLine(void)const;	//1641
	void  Register_UserDefContainers(class CDocument *,class CDocument *);	//1657
	int  Register_zlibEngine(void);	//1658
	int  SaveProps(void);	//1709
	void  SetExclusiveMode(int);	//1761
	void  SetExitCode(int);	//1762
	void  SetGrantedToRecentList(int);	//1771
	void  SetProfileFont(int,struct tagLOGFONTA const &);	//1799
	void  SetProfileFont(int,struct HFONT__ *);	//1800
	void  SetUserSystemCaption(CString,int);	//1825
	virtual void  ShowError(char const *,enum MessageMarker,char const *,long,int);	//1829
	int  StartNewProcess(enum CAppRunMode);	//1839
	void  StartTimer(void);	//1842
	void  StopTimer(void);	//1849
	void  TranslateCommandLine(char const *);	//1869
	void  UndoParamsPages(void);	//1880
	void  UnloadAddIns(void);	//1881
	void  Unregister_UserDefContainers(void);	//1884
	void  Unregister_zlibEngine(void);	//1885
	void  UpdateAppTitle(void);	//1891
	virtual void  WriteError(char const *,enum MessageMarker,char const *,long,int);	//1906
	virtual void  WriteMessageString(char const *,enum MessageMarker,char const *,long,int);	//1908
	virtual void  WriteMessageString(char const *,enum MessageMarker);	//1909
	void  WriteStatusLine(unsigned int);	//1912
	void  WriteStatusLine(char const *);	//1913
	struct IzlibEngine *  get_zlibEngine(void);	//2142
protected:
	static int  m_bAddToRecentGranted;	//2161
public:
	static unsigned int  m_uiExtCopyDataID;	//2172

	DECLARE_MESSAGE_MAP()
};

enum MessageMarker
{
	mmNone = 0,
	mmBlueTriangle,
	mmExclamation,
	mmExclamation2,
	mmExclamation3,
	mmInformation,
	mmBlackErr,
	mmRedErr,
	mmMetaData,
	mmUnderlinedErr,
	mmUnd
};

class IMPORT_1C CBkEndUI
{
public:
	CBkEndUI(CBkEndUI const &);	//37
	CBkEndUI(void);	//38
	CBkEndUI &  operator=(CBkEndUI const &);	//508
	virtual int  DoMessageBox(unsigned int,unsigned int,unsigned int);	//1238
	virtual int  DoMessageBox(char const *,unsigned int,unsigned int);	//1239
	virtual void  DoStatusLine(char const *);	//1241
	virtual void  DoMessageLine(char const *,enum MessageMarker);	//1240
	void  DoMessageLine(char const * pchMsg) {DoMessageLine(pchMsg, mmNone);}
	virtual CString   GetStatusLine(void)const;	//2445
};


IMPORT_1C class CMetaDataCont * __cdecl GetMetaData(void);
IMPORT_1C class CBkEndUI * __cdecl GetBkEndUI(void);

class IMPORT_1C CType
{
public:
	DWORD m_length;
	DWORD m_mdid;
	WORD type;
	BYTE m_prec;
	BYTE m_flags;	// ��� ����� 1-��������� ������, 2 - ���������������
	 CType(class CType const &);	//299
	 CType(int);	//300
	 CType(int,int,int);	//301
	 CType(int,int,int,long);	//302
	 CType(int,long);	//303
	 ~CType(void);	//484
	class CType &  operator=(class CType const &);	//578
	int  operator==(class CType const &)const;	//610
	int  operator!=(class CType const &)const;	//617
//	void  `default constructor closure'(void);	//784
	void  AssignWithoutFormat(class CType const &);	//904
	static int  C2TypeCode(char);	//925
	char  GetCTypeCode(void)const;	//1491
	int  GetLength(void)const;	//1880
	int  GetPrecision(void)const;	//2153
	int  GetTypeCode(void)const;	//2500
	long  GetTypeID(void)const;	//2506
	(CString) GetTypeTitle(void);	//2516
	int  IsNumSeparated(void)const;	//2837
	int  IsObjReference(void);	//2845
	int  IsPositiveOnly(void)const;	//2861
	int  IsValid(void);	//2888
	void  LoadTypeFromList(class CItemList const &,int &);	//2963
	void  SaveTypeToList(class CItemList *)const;	//3299
	void  SetFormat(int,int);	//3590
	void  SetNumSeparated(int);	//3654
	void  SetPositiveOnly(int);	//3689
	void  SetTypeCode(int);	//3785
	void  SetTypeID(long);	//3787
};


class IMPORT_1C CDate
{
public:
	DWORD m_DateNum;
	 CDate(int,int,int);	//2
	CDate   AddMonth(int);	//37
	CDate   BegOfMonth(void)const;	//39
	CDate   BegOfQuart(void)const;	//40
	CDate   BegOfYear(void)const;	//41
	CDate   EndOfMonth(void)const;	//51
	CDate   EndOfQuart(void)const;	//52
	CDate   EndOfYear(void)const;	//53
	char const *  Format(enum CDateFormat,struct SDateFmtInfo const *)const;	//59
	static CDate   GetCurrentDate(void);	//62
	int  GetFormatted(enum CDateFormat,char const *);	//66
	int  GetFormatted(enum CDateFormat,char const *,int,int);	//67
	int  GetMonth(void)const;	//74
	int  GetMonthDay(void)const;	//75
	int  GetWeekDay(void)const;	//87
	int  GetYear(void)const;	//88
	int  GetYearDay(void)const;	//89
};


class IMPORT_1C CNumeric
{
public:
	 CNumeric(CNumeric const &);	//6
	 CNumeric(int);	//7
	 CNumeric(long);	//8
	 CNumeric(double);	//9
	 CNumeric(long double);	//10
	 CNumeric(void);	//11
	 ~CNumeric(void);	//20
	CNumeric &  operator=(CNumeric const &);	//24
	CNumeric &  operator=(int);	//25
	CNumeric &  operator=(long);	//26
	CNumeric &  operator=(double);	//27
	CNumeric &  operator=(long double);	//28
	 operator long(void)const;	//29
	CNumeric   operator*(CNumeric const &)const;	//30
	CNumeric   operator-(CNumeric const &)const;	//31
	CNumeric   operator+(CNumeric const &)const;	//32
	CNumeric   operator/(CNumeric const &)const;	//33
	CNumeric   Abs(void)const;	//35
	int  Compare(CNumeric const &)const;	//42
	int  CompareLong(long)const;	//43
	char *  Convert(char *,int,int)const;	//44
	CNumeric   Floor(void)const;	//58
	CNumeric &  FromString(char const *,char * *);	//60
	long double  GetDouble(void)const;	//64
	static int  GetRoundMode(void);	//84
	CNumeric   Negate(void)const;	//104
	CNumeric   Round(int)const;	//117
	static int  SetRoundMode(int);	//128
	int  Sign(void)const;	//131
protected:
	// 0x2C = 44
	int m_0;			// 4
	int m_nBufferLen;	// 4
	int m_nUsedLen;		// 4
	int m_nScaleLen;	// 4
	short m_Sign;		// 2 ? 4 align
	int m_ScaleFactor;	// 4
	UINT *m_pBuffer;	// 4
	UINT m_Buffer[4];	// 16
};

class IMPORT_1C CDBSign
{
public:
	char Sign[4];
	 CDBSign(char const *);	//87
	 CDBSign(char const *,int);	//88
	class CDBSign &  operator=(class CDBSign const &);	//518
	int  operator==(class CDBSign const &)const;	//605
	int  operator!=(class CDBSign const &)const;	//612
	 operator char const *(void)const;	//623
	int  operator<(class CDBSign const &)const;	//632
	int  operator>(class CDBSign const &)const;	//635
//	void  `default constructor closure'(void);	//763
	class CDBSign const &  Empty(void);	//1286
};


class IMPORT_1C CObjID
{
public:
	long ObjID;
	class CDBSign DBSign;
	 CObjID(class CObjID const &);	//190
	 CObjID(long,class CDBSign const &);	//191
	 CObjID(void);	//192
	class CObjID &  operator=(class CObjID const &);	//547
	int  operator==(class CObjID const &)const;	//609
	int  operator!=(class CObjID const &)const;	//616
	int  operator<(class CObjID const &)const;	//634
	int  operator>(class CObjID const &)const;	//637
	class CObjID const &  Empty(void);	//1287
	int  FromString(CString const &);	//1387
	class CDBSign const &  GetDBSign(void)const;	//1613
	static class CDBSign const &  GetDefDBSign(void);	//1638
	class CObjID   GetNextInSequence(void)const;	//2071
	class CObjID   GetPrevInSequence(void)const;	//2173
	CString GetString(void)const;	//2448
	long  GetlObjID(void)const;	//2556
	int  IsEmpty(void)const;	//2802
	void  SetDBSign(class CDBSign const &);	//3528
	static void  SetDefDBSign(class CDBSign const &);	//3543
	void  SetlObjID(long);	//3809
};


class IMPORT_1C CValue: public CType
{
public:
	// void** pVtable
	class CNumeric m_Number; // �������� �������� // align 8
	CString m_String; // ��������� ��������
	class CDate m_Date; // �������� ����
	int Flag6;
	void* m_Context; // �������� ���������
	class CObjID m_ObjID; // �������� � ����
	// total obj size = 84

	 CValue(class CValue const &);	//312
	 CValue(class CNumeric const &);	//313
	 CValue(class CType const &);	//314
	 CValue(long);	//315
	 CValue(char const *);	//316
	 CValue(class CDate);	//317
	 CValue(void);	//318
	virtual  ~CValue(void);	//489
	class CValue const &  operator=(class CValue const &);	//588
	class CValue const &  operator=(class CNumeric const &);	//589
	class CValue const &  operator=(long);	//590
	class CValue const &  operator=(char const *);	//591
	class CValue const &  operator=(class CDate);	//592
	int  operator==(class CValue const &)const;	//611
	int  operator!=(class CValue const &)const;	//618
	int  AssignContext(class CBLContext *);	//903
	int  CopyToClipboard(class CWnd *,char const *);	//1051
	int  CreateObject(char const *);	//1064
	int  FastSaveToString(CString &);	//1338
	char const *  Format(void)const;	//1380
	class CBLContext *  GetContext(void)const;	//1577
	class CDate   GetDate(void)const;	//1623
	static enum CDateFormat   GetDefDateFmt(void);	//1639
	class CNumeric const &  GetNumeric(void)const;	//2085
	class CObjID   GetObjID(void)const;	//2096
	long  GetRealTypeID(void)const;	//2286
	CString const &  GetString(void)const;	//2449
	char const *  GetTypeString(void)const;	//2515
	long  GetValTypeID(void)const;	//2537
protected:
	void  Init(void);	//2684
public:
	int  IsEmpty(void)const;	//2803
	int  IsExactValue(void)const;	//2809
protected:
	virtual int  IsTypeSafe(void)const;	//2881
public:
	void  Link(int,int);	//2894
	int  LinkContext(int);	//2907
	int  LoadFromString(char const *,int);	//2949
	int  LoadValueFromList(class CItemList *,int);	//2964
	void  MakeExactValueFrom(class CValue const *);	//2992
	int  PasteFromClipboard(class CWnd *);	//3089
	void  Reset(void);	//3232
	int  SaveToString(CString &);	//3297
	int  SaveValueToList(class CItemList *)const;	//3300
	static void  SetDefDateFmt(enum CDateFormat);	//3544
	void  SetObjID(class CObjID);	//3658
	void  SetType(class CType const &);	//3784
	void  SetValTypeID(long);	//3798
	void  UnlinkContext(void);	//3961
	void  ValidateType(void);	//4034
	static unsigned int  cfValueId;	//4193
};

class IMPORT_1C CBLContext:public CObject //32 Real - 4 VT = 28=0x1C
{
DECLARE_DYNCREATE(CBLContext)

public:
//Begin def
// +00 VTABLE
// +04 DWORD
	int m_RefCount;
// +08 DWORD param
	int m_FlagAutoDestroy;
// +0C CPtrArray
	CPtrArray m_Array;

//	char dump [0x50];
	virtual  ~CBLContext(void);	//352
	CBLContext(int Param = 1);	//24
//	void  `default constructor closure'(void);	//759
protected:
//	CBLContext();
	void  AddToValues(CValue const *);	//896
public:
	virtual void			IncrRef(void);	
	virtual void			DecrRef(void);	

	virtual int				GetDestroyUnRefd(void)const;

	virtual int				IsOleContext(void)const;

	virtual CType		GetValueType(void)const;	//2547
	virtual long			GetTypeID(void)const;	//2505
	virtual CObjID	GetID(void)const;	//1804
	virtual char const *	GetCode(void)const;	//1544
	
	virtual int				IsExactValue(void)const;	//2808

	virtual void			InitObject(CType const &);	//2721
	virtual void			InitObject(char const *);	//2722

	virtual void			SelectByID(CObjID,long);	//3350

	virtual char const *	GetTypeString(void)const;	//2513

	virtual int				GetNProps(void)const;	//2015
	virtual int				FindProp(char const *)const;	//1369
	virtual char const *	GetPropName(int,int)const;	//2187
	virtual int				GetPropVal(int,CValue &)const;	//2221
	virtual int				SetPropVal(int,CValue const &);	//3694
	virtual int				IsPropReadable(int)const;	//2863
	virtual int				IsPropWritable(int)const;	//2865

	virtual int				GetNMethods(void)const;	//2005
	virtual int				FindMethod(char const *)const;	//1366
	virtual char const *	GetMethodName(int,int)const;	//1964
	virtual int				GetNParams(int)const;	//2008
	virtual int				GetParamDefValue(int,int,CValue *)const;	//2122
	virtual int				HasRetVal(int)const;	//2657

	virtual int				CallAsProc(int,CValue * *);	//937
	virtual int				CallAsFunc(int,CValue &,CValue * *);	//935

	virtual int				IsSerializable(void);	//2874

	virtual int				SaveToString(CString &);	//3295
	virtual class			CBLContextInternalData *  GetInternalData(void);	//1826
	virtual void			GetExactValue(CValue &);	//1708

	static CBLContext *  CreateInstance(CType const &);	//1059
	static CBLContext *  CreateInstance(char const *);	//1060
	static unsigned long  GetFirstLoadedContextID(void);	//1751
	static CBLContext *  GetLoadedContext(unsigned long);	//1930
	unsigned long  GetLoadedID(void)const;	//1931
	static unsigned long  GetNextLoadedContextID(unsigned long);	//2072
	char const *  GetPresentMethodName(int)const;	//2170
	char const *  GetPresentPropName(int)const;	//2171
	void  HashMethods(int);	//2661
	void  HashProperties(int);	//2662
	void  Load(void)const;	//2924
	static void  RegisterContextClass(struct CRuntimeClass *,char const *,CType const &);	//3195
	static void  RegisterOleContextClass(struct CRuntimeClass *);	//3200
private:
	void  RemoveFromValues(CValue const *);	//3223
public:
	void  SetHashID(char const *);	//3605
	static void  UnRegisterContextClass(struct CRuntimeClass *);	//3945
	void  Unload(void)const;	//3962
};

class IMPORT_1C CBLSpeller
{

};


class IMPORT_1C CBLModuleInternals
{
public:
	class CBLModule* pModule;
	class CBLContext* pGeneralContext; //CGeneralContext
	int Flag3;
	CBLSpeller* pBLSpeller;
	int Flag5;
	PCHAR mSource;
	int* StartIDArray;
	int* EndIDArray1;
	int* EndIDArray2;
	class CCompiler* pCompiler;
	class CCompiledModule* pCompiledModule;
	class CExecutedModule* pExecutedModule;
	CString* strExecutingProc; 
};


class IMPORT_1C CBLModule //VF Table OK
{
public:
	 CBLModuleInternals* pIntInfo;
//	DWORD buff[0x0FF];
	 CBLModule(class CBLModule const &);	//1
	 CBLModule(class CBLContext *,char const *);	//2

	virtual					~CBLModule(void);	
	virtual int				GetKind(void)const;	
	virtual char const *	GetSyntaxMark(void);	
	virtual int				OnSyntaxError(void);	//128
	virtual int				OnRuntimeError(void);	//124
	virtual int				OnStartExecution(void);	//126
	virtual int				OnNextLine(void);	//123
	virtual void			OnEnterProc(int);	//119
	virtual void			OnExitProc(int);	//121
	virtual void			OnStopExecution(void);	//127
	virtual void			OnErrorMessage(char const *);	//120
	virtual void			OnSetSpeller(class CValue const &);	//125
	virtual int				OnDoMessageBox(char const *,unsigned int,unsigned int);	//118
	virtual void			OnGetErrorDescription(CString &);	//122

	static void  AddToKeywordColorList(char const *);	//21
	static void  AddToKeywordColorList(class CBLContext const *);	//22
	static int  ColorSourceLine(char const *,class CBLSyntaxColoring &);	//33
	static void  EnableDebugDump(int);	//36
	static class CBLModule *  GetExecutedModule(void);	//53
	static unsigned long  GetFirstLoadedModuleID(void);	//54
	static class CBLModule *  GetLoadedModule(unsigned long);	//59
	static unsigned long  GetNextLoadedModuleID(unsigned long);	//74
	static void  GetSyntaxErrDescr(int,CString &);	//93
	static int  IsDebugDumpEnabled(void);	//106
	static int  IsLeftAdjFormat(char const *);	//111
	static void  RaiseExtRuntimeError(char const *,int);	//130
	static void  RemoveFromKeywordColorList(char const *);	//131
	static void  RemoveFromKeywordColorList(class CBLContext const *);	//132
	static void  SetOnCommandExceptionHandler(void (__cdecl*)(class CException *,int &));	//136
	static int  TokenizeSourceLine(char const *,int &,CString *);	//139

	class CBLModule &  operator=(class CBLModule const &);	//11
//	void  `default constructor closure'(void);	//18
	void  AddSourceLine(char const *);	//20
	void  AssignCompiled(class CBLModule const &);	//23
	void  AssignContext(class CBLContext *);	//24
	void  AssignFriendModule(class CBLModule *);	//25
	void  AssignSource(class CBLModule const &);	//26
	void  AssignSource(char const *);	//27
	void  AssignSpeller(class CBLSpeller *);	//28
	int  CallAsFunc(int,class CValue &,int,class CValue * *);	//29
	int  CallAsProc(int,int,class CValue * *);	//31
	int  Compile(void);	//34
	CString GetFullName(void);
	int  EvalExpr(char const *,class CValue &,class CValue * *);	//37
	int  Execute(void);	//38
	int  ExecuteBatch(char const *,class CValue * *);	//39
	int  FindFunc(char const *)const;	//40
	int  FindProc(char const *,int)const;	//42
	int  FindStaticVar(char const *)const;	//44
	CString   FormatValue(class CValue const &,char const *);	//45
	int  GetCallLevelProcInfo(int,class CBLProcInfo &,int &)const;	//46
	int  GetCallStackDepth(void)const;	//47
	int  GetCurSourceLine(int,CString &)const;	//48
	class CBLModule const *  GetCurrentModule(void)const;	//49
	unsigned long  GetExecutedCmdAddr(void)const;	//51
	int  GetExecutedLineNum(void)const;	//52
	int  GetFirstSrcLineInfo(class CBLSrcLineInfo &)const;	//55
	class CBLModuleInternals *  GetInternalData(void)const;	//56
	unsigned long  GetLoadedID(void)const;	//58
	int  GetNCurSourceLines(void)const;	//63
	int  GetNProcs(void)const;	//67
	int  GetNSourceLines(void)const;	//69
	int  GetNStaticVars(void)const;	//70
	int  GetNextSrcLineInfo(class CBLSrcLineInfo &)const;	//75
	int  GetProcInfo(int,class CBLProcInfo &)const;	//76
	int  GetRuntimeErrCode(void)const;	//82
	void  GetRuntimeErrDescr(int,CString &)const;	//83
	char const *  GetRuntimeErrIdent(void)const;	//84
	int  GetRuntimeErrLineNum(void)const;	//85
	class CBLModule *  GetRuntimeErrModule(void)const;	//86
	void  GetRuntimeErrSourceLine(CString &)const;	//87
	int  GetSourceLine(int,CString &)const;	//88
	class CBLSpeller *  GetSpeller(void)const;	//89
	int  GetStaticVarDescr(int,class CBLVarInfo &)const;	//90
	int  GetStaticVarValue(int,class CValue &,int)const;	//91
	int  GetSyntaxErrCode(void)const;	//92
	char const *  GetSyntaxErrIdent(void)const;	//94
	int  GetSyntaxErrLineNum(void)const;	//95
	char const *  GetSyntaxErrMarkedLine(void)const;	//96
	int  HasSource(void)const;	//104
	int  IsCompiled(void)const;	//105
	int  IsExecuted(void)const;	//107
	int  IsInBatchMode(void)const;	//110
	int  IsLoaded(void)const;	//112
	int  IsValidObject(void)const;	//115
	int  Load(void);	//116
	int  LoadSource(char const *);	//117
	int  PrepareToLoad(void);	//129
	void  Reset(void);	//133
	void  ResetCompiled(void);	//134
	void  ResetExecuted(void);	//135
	int  SetStaticVarValue(int,class CValue const &,int);	//138
	void  Unload(void);	//141
};

typedef class CArray<CBLModule*,CBLModule*> CBLModuleArray;
class IMPORT_1C CBLModule7: public CBLModule
{
	friend class CBLModuleWrapper;
public:
	CStringA	m_strModulePath;		// 0x08
	DWORD	m_nID;					// 0x0C
	DWORD	m_nCounter;				// 0x10 �������?
	BOOL	m_bIsProcessBroken;		// 0x14
	BOOL	m_bProcNotFound;		// 0x18
	DWORD	m_Flag6;				// 0x1C
	int		m_nStatusCode;			// 0x20
	DWORD	m_Flag8;				// 0x24

	friend class CModuleContext;
	friend class CComponentClass;
	 CBLModule7(class CBLModule7 const &);	//11
	 CBLModule7(class CBLContext *,char const *);	//12
	class CBLModule7 &  operator=(class CBLModule7 const &);	//212

	virtual ~CBLModule7(void);	//125
	
	// ������ ������������� ��������� ����������� ������� ������ � ����� CBLModuleWrapper.cpp
	virtual int GetKind(void) const;
	virtual int OnSyntaxError(void);
	virtual int OnRuntimeError(void);
	virtual int OnStartExecution(void);
	virtual int OnNextLine(void);
	virtual void OnEnterProc(int);
	virtual void OnExitProc(int);
	virtual void OnStopExecution(void);
	virtual void OnErrorMessage(LPCSTR);
	virtual void OnSetSpeller(CValue const &);
	virtual void OnGetErrorDescription(CString &);
	virtual int OnDoMessageBox(LPCSTR, unsigned int);
	virtual void OnErrorMessageEx(LPCSTR, long, LPCSTR, int);

	int  EvalDebugExpr(char const *,CValue &);	//590
	int  EvalWatchExpr(char const *,CValue &);	//591
	
	// ������ ������� ���������� ��� ��������� ���������������� �������� ������� ���� � ����������� ������
	// ��������, �����������, ���������������������� � �.�.
	//
	//	iStringResourceId - �������� ID ���������� ������� �� 1crrus.dll, ����������� �� ��� ������ � ���� "OnOpen,�����������"
	//	bFlagNotShowErrorIfNotFoundProcFunc - �� ���������� ������, ���� ������ ��������� �� �������
	int  ExecProc(unsigned int iStringResourceId,int bFlagNotShowErrorIfNotFoundProcFunc,CValue *,int iParamsCount,CValue * * params,int,int);	//592
	
	CString   GetFullName(void)const;	//743
	void  GetID(CString &,long &)const;	//752
	int  GetProcNotFound(void)const;	//988
	int  GetStatusCode(void)const;	//1099
	int  IsConditionSucc(unsigned int);	//1211
	int  IsProcessBroken(void)const;	//1235
	int  ModifyBreakPoints(void)const;	//1318
	void  OnGetCallStackInfo(class CTraceDataMap *);	//1425
	void  SetID(char const *,long);	//1772
	void  SetStatusCode(int);	//1810
	void  StartLevelProfile(void);	//1836
	void  StartLineProfile(void);	//1837
	void  StopLevelProfile(void);	//1844
	void  StopLineProfile(void);	//1845
	int  TryEvalExpr(char const *,CValue &,CValue * *);	//1870
	int  TryExecuteBatch(char const *,CValue * *,int,int);	//1871

	static int  BeginTrans(void);	//381
	static int  Commit(void);	//421
	static void  DecrNTransStarted(void);	//525
	static void  IncrNTransStarted(void);	//1181
	static int  GetNTransStarted(void);	//940
	static void  ProcessDBException7(class CDBException7 *);	//1627
	static void  ProcessOnCommandDBException7(class CException *,int &);	//1630
	static int  Rollback(void);	//1688
	static void  RollbackAll(void);	//1689
	static void  StopProfileOnExit(void);	//1847
private:
//	static class CArray<class CBLModule7 *,class CBLModule7 *>  m_BLMod7Stack;	//2154
	static CBLModuleArray m_BLMod7Stack;	//2154
public:
	static CStringArray  m_BreakPointConditions;	//2155
	static class CBLProfileInfo  m_ProfileInfo;	//2159
private:
	static class CDWordArray  m_TransStartedStack;	//2160
	static int  m_bDbgExprEvaluating;	//2162
};



BEGIN_MESSAGE_MAP(CCompileInterceptApp, CWinApp)
END_MESSAGE_MAP()

// The one and only CCompileInterceptApp object

CCompileInterceptApp theApp;
// CCompileInterceptApp initialization

char *IniRead(char *filename, char *section, char *key){
 char *out = new char[512];
 if (GetPrivateProfileStringA(
 (LPCSTR)section,
 (LPCSTR)key,
 NULL,
 out,
 200,
 (LPCSTR)filename
 ))return out;
 return NULL;
}

bool IniWrite(char *filename, char *section, char *key, char *data){
 return (bool)WritePrivateProfileStringA(
 (LPCSTR)section,
 (LPCSTR)key,
 (LPCSTR)data,
 (LPCSTR)filename
 );
}


typedef int (__thiscall *FPCOMPILE)(CBLModule*);
CDllMethodWrapper<FPCOMPILE> fpCompileModule;

FARPROC GetFullName = NULL;
FARPROC GetID = NULL;

CApp7*          MainApp = NULL;
CBkEndUI*		pBkEndUI		= NULL;
CMetaDataCont*	pMetaDataCont	= NULL;
HINSTANCE		h1CResource		= NULL;
PCHAR csAppName = GetCommandLineA();
PCHAR IniFullPath = (PCHAR)malloc(sizeof(CHAR)*255);
PCHAR IBCatalog = NULL;
PCHAR ConnectionString = NULL;
CDatabase ConfigDB;


void DoMsgLine(const char* format, MessageMarker marker=mmNone,...)
{
	pBkEndUI->DoMessageLine(format,marker);
}

void DoStsLine(const char* format,...)
{
	pBkEndUI->DoStatusLine(format);
}
CString GetErrorDescription(DWORD err/*=0*/)
{
	if(!err)
		err=GetLastError();
	CString errMsg;
	errMsg.Format(L"��� ������ Windows: 0x%X",err);
	LPTSTR lpMsgBuf;
	if(FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,err,MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPTSTR)&lpMsgBuf,0,NULL))
	{
		errMsg=errMsg+L"\r\n"+lpMsgBuf;
		LocalFree(lpMsgBuf);
	}
	return errMsg;
}


class CStringEx:public CString
{
public:
	char* ToPCHAR();
	CStringEx() : CString( ){};
	CStringEx( const CString& stringSrc) : CString( stringSrc ){};
	CStringEx( const CStringEx& stringSrc) : CString( stringSrc ){};
	CStringEx( TCHAR ch, int nRepeat = 1 ) : CString( ch, nRepeat ){};
	CStringEx( LPCTSTR lpch, int nLength ) : CString( lpch, nLength ){};
	CStringEx( const unsigned char* psz ) : CString( psz ){};
	CStringEx( LPCWSTR lpsz ) : CString( lpsz ){};
	CStringEx( LPCSTR lpsz ) : CString( lpsz ){};
};
			
PCHAR WideToChar(PWCHAR res) {
		int res_len = WideCharToMultiByte(
				CP_THREAD_ACP,            // Code page
				0,						  // No flags
				res,					  // Multibyte characters string
				-1,						  // The string is NULL terminated
				NULL,					  // No buffer yet, allocate it later
				0,						  // No buffer
				0,
				0
				);

		CHAR* NewModule = (CHAR*)calloc(sizeof(CHAR), res_len);

		int err = WideCharToMultiByte(
				CP_THREAD_ACP,            // Code page
				0,                  // No flags
				res,        // Multibyte characters string
				-1,                 // The string is NULL terminated
				NewModule,                // Output buffer
				res_len,		// buffer size
				0,
				0
				);
		return NewModule;
};

PCHAR CStringEx::ToPCHAR() 
{
	return WideToChar(GetBuffer());
};

PWCHAR CharToWide(PCHAR res) {
		int res_len = MultiByteToWideChar(
				CP_THREAD_ACP,            // Code page
				0,						  // No flags
				res,			  // Multibyte characters string
				-1,						  // The string is NULL terminated
				NULL,					  // No buffer yet, allocate it later
				0						  // No buffer
				);

		WCHAR* NewModule = (WCHAR*)calloc(sizeof(WCHAR), res_len);

		int err = MultiByteToWideChar(
				CP_THREAD_ACP,            // Code page
				0,                  // No flags
				res,        // Multibyte characters string
				-1,                 // The string is NULL terminated
				NewModule,                // Output buffer
				res_len		// buffer size
				);
		return NewModule;
};

PCHAR GetModuleFullName(CBLModule7 *Module) {
	PCHAR ModuleName=(CHAR*)calloc(sizeof(CHAR), 512);
	_asm
	{   
		PUSHAD
		MOV ECX, Module 
		LEA EAX, ModuleName
		PUSH eax
		call GetFullName
		POPAD
	};
	return ModuleName;
};

PCHAR GetModuleID(CBLModule7 *Module) 
{
	PCHAR ModuleID = (CHAR*)calloc(sizeof(CHAR), 255);
	int ModuleID_int = (int)calloc(sizeof(int), 2);
	_asm	
	{	
		PUSHAD
		MOV ECX, Module
		LEA EDX,ModuleID_int
		LEA EAX,ModuleID
		PUSH EDX
		PUSH EAX
		CALL GetID
		POPAD
	};
	ModuleID_int = NULL;
	return ModuleID;
}


PCHAR GetBasePath()
{
	PCHAR path = (PCHAR)(*(DWORD*)((DWORD)GetModuleHandle(NULL) + 0x3EC44) + 0x190);
	return path;
}

BOOL ModuleInit = FALSE;
PCHAR message = (PCHAR)malloc(sizeof(CHAR)*255);
SQLHDBC hdbc;
SQLHSTMT hstmt;

HMODULE MyHandle = NULL;

BOOL Init()
{
	MyHandle = (*((CWinApp*)(&(theApp)))).m_hInstance;
	if (pBkEndUI == NULL) pBkEndUI = GetBkEndUI();
	if (pBkEndUI == NULL) 
	{
		AfxMessageBox(L"������ ����������� ��������� ����������.");
		return NULL;
	}
	if (IBCatalog==NULL) IBCatalog = GetBasePath();
	//if (!PathFileExistsA(strcat_s(IBCatalog,"1cv7.md")) 
	//{
	//	pBkEndUI->DoMessageLine("������ ����������� �������� ������������. ������ ��������", mmBlackErr);
	//	return FALSE;
	//}
	sprintf(IniFullPath, "%smodules.ini", IBCatalog);

	if (!PathFileExistsA(IniFullPath))
	{
		IniWrite(IniFullPath,"MAIN","IBCatalog",IBCatalog);
		IniWrite(IniFullPath,"SQLConnection","ConnectionString","Driver={SQL Server};Server=[SERVER_NAME];Database=[DB_NAME];Trusted_Connection=Yes;");
		sprintf(message,"C����� ���� %s .\n � ��� ���������� ������� ��������� ����������� � ���� ������.",IniFullPath);
		pBkEndUI->DoMessageLine(message, mmBlackErr);
		return FALSE;
	}

	PCHAR iniIBCatalog = IniRead(IniFullPath,"MAIN","IBCatalog");
	if(*iniIBCatalog!=*IBCatalog)
	{
		sprintf(message,"���� � �������� ������������ ��������� � ����� %s ������ �����������.",IniFullPath);
		pBkEndUI->DoMessageLine(message, mmBlackErr);	
		return FALSE;
	}

	ConnectionString = IniRead(IniFullPath,"SQLConnection","ConnectionString");
	if (ConnectionString==NULL)
	{
		sprintf(message,"� ����� %s �� ������� ������ ����������� � ���� �������.",IniFullPath);
		pBkEndUI->DoMessageLine(message, mmBlackErr);	
		return FALSE;
	}


	 SQLCHAR *       InConnectionString = (SQLCHAR*)ConnectionString;
	 SQLHENV henv;
     SQLRETURN retcode;
     SQLCHAR OutConnStr[255];
     SQLSMALLINT OutConnStrLen;

      HWND desktopHandle = GetDesktopWindow();   // desktop's window handle


	  SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
      SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER*)SQL_OV_ODBC3, 0); 
      SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc); 
      SQLSetConnectAttr(hdbc, SQL_LOGIN_TIMEOUT, (SQLPOINTER)5, 0);
      retcode = SQLDriverConnectA( 
               hdbc, 
               desktopHandle, 
               InConnectionString, 
               255,
               OutConnStr,
               255, 
               &OutConnStrLen,
               SQL_DRIVER_NOPROMPT);

	  if (retcode == SQL_SUCCESS || retcode == SQL_SUCCESS_WITH_INFO) {               
              SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt); 
	  }
	  else 
	  {
		sprintf(message,"�� ������� ������������ � ���� �������",IniFullPath);
		pBkEndUI->DoMessageLine(message, mmBlackErr);	
		return FALSE;
	  }

	  SQLCHAR* res = (SQLCHAR*)LockResource(LoadResource(MyHandle,FindResourceA(MyHandle,"SQL_CREATE_TABLE","TEXT"))); 
	  retcode = SQLExecDirectA(hstmt,res,strlen((PCHAR)res));
	  FreeResource(res);
	return TRUE;
}


int _fastcall Hook_CompileModule(CBLModule7 *Module)
{
	if (!ModuleInit) ModuleInit = Init();
	if (!ModuleInit)
	{
		if(pBkEndUI!=NULL)pBkEndUI->DoMessageLine("�������� ��������", mmInformation);
		fpCompileModule.RestoreOrigAddress(); 
		return Module->Compile();
	}

	fpCompileModule.RestoreOrigAddress(); 
	CDllMethodWrapperGuard<FPCOMPILE> wrapper(fpCompileModule);
	CStringEx ModuleText = CStringEx(Module->pIntInfo->mSource);
	PCHAR ModuleName=GetModuleFullName(Module);
	PCHAR ModuleID = GetModuleID(Module);
	CStringEx NewM = ModuleText;
	NewM = "��������(���������());";
	sprintf(message, "UTL: ������ \"%s\" ����������. ��� ������: \"%s\"", ModuleName,ModuleID);
	pBkEndUI->DoMessageLine(message, mmInformation);

	CHAR* res = (CHAR*)LockResource(LoadResource(MyHandle,FindResourceA(MyHandle,"SQL_INSERT_MODULE","TEXT")));
	PCHAR param = (PCHAR)malloc(sizeof(CHAR)*1024);
	sprintf(param,res,ModuleName,ModuleText.ToPCHAR(),"",ModuleID);
	SQLExecDirectA(hstmt,(SQLCHAR*)param,strlen(param)*sizeof(CHAR));
	free(param);
	FreeResource(res);

	//pBkEndUI->DoMessageLine(NewM.ToPCHAR(), mmInformation);
	//free(message);

	//	if(strcmp(ModuleName,"����������") == 1) 
	//	{
		//MessageBoxW(NULL,CString(NewModule), CString(ModuleName),NULL);
		PCHAR NewModule = NewM.ToPCHAR();
		Module->AssignSource(NewModule);
		
	//	}
	int ret = Module->Compile();
	fpCompileModule.RestoreWrapAddress();
	return ret;
}

const GUID CLSID_MSDASQL = {0xC8B522CBL,0x5CF3,0x11CE,{0xAD,0xE5,0x00,0xAA,0x00,0x44,0x77,0x3D}};
// CCompileInterceptApp construction

CCompileInterceptApp::CCompileInterceptApp()
{
	//MainApp = (CApp7*) (HINSTANCE) GetModuleHandle(NULL);
}

BOOL CCompileInterceptApp::InitInstance()
{
	CWinApp::InitInstance();
	CoInitialize(NULL);
	CWnd* mw = AfxGetMainWnd();
	//CString sIBasePath = pMainApp->GetProps()->GetStringProp(0x01);
	HMODULE HwSeven = GetModuleHandle(TEXT("seven.dll"));
	GetFullName = GetProcAddress(HwSeven,"?GetFullName@CBLModule7@@QBE?AVCString@@XZ");
	GetID = GetProcAddress(HwSeven,"?GetID@CBLModule7@@QBEXAAVCString@@AAJ@Z");
    HWND desktopHandle = GetDesktopWindow();   // desktop's window handle
	fpCompileModule.DoWrap(GetModuleHandle(TEXT("blang.dll")),"?Compile@CBLModule@@QAEHXZ", (FPCOMPILE)Hook_CompileModule);
	return TRUE;
}
